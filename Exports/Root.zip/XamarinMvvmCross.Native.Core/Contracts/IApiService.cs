﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    /// <summary>
    /// A sample service contract used in IoC/DI
    /// </summary>
    public interface IApiService
    {
    }
}
