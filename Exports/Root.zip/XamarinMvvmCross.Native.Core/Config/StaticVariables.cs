﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Config
{
    /// <summary>
    /// Exposes static variables for use across the application
    /// </summary>
    public class StaticVariables
    {
        public static string SomeStaticVariable => "";
    }
}
