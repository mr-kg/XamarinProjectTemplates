﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Config
{
    /// <summary>
    /// Used for storing config variables that should be tokenized and injected at build-time
    /// </summary>
    public class ApplicationConfig
    {
        public static string SomeTokenizedVariable => "";
    }
}
