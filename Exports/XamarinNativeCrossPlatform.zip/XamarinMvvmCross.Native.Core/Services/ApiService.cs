﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    /// <summary>
    /// A sample service used in IoC/DI
    /// </summary>
    public class ApiService : IApiService
    {
    }
}
