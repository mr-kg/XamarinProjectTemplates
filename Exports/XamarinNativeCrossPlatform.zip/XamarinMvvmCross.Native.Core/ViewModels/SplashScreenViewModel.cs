﻿using MvvmCross.Core.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.ViewModels
{
    public class SplashScreenViewModel : BaseViewModel
    {
    }
}
